// During development, we'll use local storage instead of Supabase
export const storage = {
  uploadImage: async (file: File): Promise<string> => {
    return new Promise((resolve) => {
      const reader = new FileReader();
      reader.onloadend = () => {
        resolve(reader.result as string);
      };
      reader.readAsDataURL(file);
    });
  },
  
  removeImage: async (url: string): Promise<void> => {
    // In local storage, we don't need to do anything to remove the image
    return Promise.resolve();
  }
};