import { useState, useEffect, useCallback } from 'react';
import { format, parseISO } from 'date-fns';
import { MapPin, Search, ChevronDown, ChevronUp, Navigation, RotateCcw, Route, Play, Pause, Flag, MapPinOff } from 'lucide-react';
import { ContainerData } from './Dashboard';
import toast from 'react-hot-toast';

interface SavedLocationsProps {
  containers: ContainerData[];
}

interface OptimizedRoute {
  container: ContainerData;
  location: {
    lat: number;
    lng: number;
    address: string;
  };
  distance: number;
  duration: number;
}

interface JourneyStatus {
  isActive: boolean;
  currentStop: number;
  startTime: string | null;
  completedStops: string[];
}

export function SavedLocations({ containers }: SavedLocationsProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [sortField, setSortField] = useState<keyof ContainerData>('unique_codify');
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('asc');
  const [expandedLocation, setExpandedLocation] = useState<string | null>(null);
  const [currentLocation, setCurrentLocation] = useState<{ lat: number; lng: number } | null>(null);
  const [optimizedRoute, setOptimizedRoute] = useState<OptimizedRoute[]>([]);
  const [isCalculatingRoute, setIsCalculatingRoute] = useState(false);
  const [journeyStatus, setJourneyStatus] = useState<JourneyStatus>({
    isActive: false,
    currentStop: 0,
    startTime: null,
    completedStops: []
  });

  const containersWithLocations = containers.filter(container => 
    container.locations && container.locations.length > 0
  );

  const filteredContainers = containersWithLocations.filter(container =>
    container.unique_codify.toLowerCase().includes(searchTerm.toLowerCase()) ||
    container.retail_outlet_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    container.phone_number.includes(searchTerm) ||
    container.locations?.some(loc => 
      loc.customer_name?.toLowerCase().includes(searchTerm.toLowerCase())
    )
  );

  const sortedContainers = [...filteredContainers].sort((a, b) => {
    const aValue = a[sortField];
    const bValue = b[sortField];
    const direction = sortDirection === 'asc' ? 1 : -1;
    return aValue < bValue ? -1 * direction : 1 * direction;
  });

  const handleSort = (field: keyof ContainerData) => {
    if (field === sortField) {
      setSortDirection(prev => prev === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortDirection('asc');
    }
  };

  const SortIcon = ({ field }: { field: keyof ContainerData }) => {
    if (field !== sortField) return null;
    return sortDirection === 'asc' ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />;
  };

  const openInGoogleMaps = (lat: number, lng: number) => {
    window.open(`https://www.google.com/maps?q=${lat},${lng}`, '_blank');
  };

  const calculateDistances = useCallback(async (
    origin: { lat: number; lng: number },
    destinations: { lat: number; lng: number }[]
  ): Promise<{ distances: number[]; durations: number[] }> => {
    try {
      const distances = destinations.map(dest => {
        const R = 6371e3;
        const φ1 = origin.lat * Math.PI / 180;
        const φ2 = dest.lat * Math.PI / 180;
        const Δφ = (dest.lat - origin.lat) * Math.PI / 180;
        const Δλ = (dest.lng - origin.lng) * Math.PI / 180;

        const a = Math.sin(Δφ/2) * Math.sin(Δφ/2) +
                Math.cos(φ1) * Math.cos(φ2) *
                Math.sin(Δλ/2) * Math.sin(Δλ/2);
        const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));

        return R * c;
      });

      const durations = distances.map(distance => (distance / 1000) * (60 / 30) * 60);

      return { distances, durations };
    } catch (error) {
      console.error('Error calculating distances:', error);
      toast.error('Error calculating distances');
      return { distances: [], durations: [] };
    }
  }, []);

  const optimizeRoute = useCallback(async () => {
    if (!currentLocation) {
      toast.error('Please enable location services to optimize the route');
      return;
    }

    setIsCalculatingRoute(true);

    try {
      const containersWithLatestLocations = containersWithLocations.map(container => ({
        container,
        location: container.locations![container.locations!.length - 1]
      }));

      const destinations = containersWithLatestLocations.map(({ location }) => ({
        lat: location.lat,
        lng: location.lng
      }));

      const { distances, durations } = await calculateDistances(currentLocation, destinations);

      const routeWithDistances = containersWithLatestLocations.map((item, index) => ({
        container: item.container,
        location: {
          lat: item.location.lat,
          lng: item.location.lng,
          address: item.location.address
        },
        distance: distances[index],
        duration: durations[index]
      }));

      const sortedRoute = routeWithDistances.sort((a, b) => a.distance - b.distance);
      setOptimizedRoute(sortedRoute);

      toast.success('Route optimized successfully!');
    } catch (error) {
      console.error('Error optimizing route:', error);
      toast.error('Failed to optimize route');
    } finally {
      setIsCalculatingRoute(false);
    }
  }, [currentLocation, containersWithLocations, calculateDistances]);

  const getCurrentLocation = useCallback(async () => {
    if (!navigator.geolocation) {
      toast.error('Geolocation is not supported by your browser');
      return;
    }

    try {
      const position = await new Promise<GeolocationPosition>((resolve, reject) => {
        navigator.geolocation.getCurrentPosition(resolve, reject, {
          enableHighAccuracy: true,
          timeout: 5000,
          maximumAge: 0
        });
      });

      setCurrentLocation({
        lat: position.coords.latitude,
        lng: position.coords.longitude
      });

      toast.success('Location detected successfully');
    } catch (error) {
      console.error('Error getting location:', error);
      toast.error('Failed to get current location');
    }
  }, []);

  const resetRoute = () => {
    setOptimizedRoute([]);
    setCurrentLocation(null);
    setJourneyStatus({
      isActive: false,
      currentStop: 0,
      startTime: null,
      completedStops: []
    });
  };

  const startJourney = () => {
    setJourneyStatus({
      isActive: true,
      currentStop: 0,
      startTime: new Date().toISOString(),
      completedStops: []
    });
    
    // Open the first location in Google Maps
    if (optimizedRoute.length > 0) {
      const firstStop = optimizedRoute[0];
      openInGoogleMaps(firstStop.location.lat, firstStop.location.lng);
      toast.success('Journey started! Navigate to your first stop.');
    }
  };

  const pauseJourney = () => {
    setJourneyStatus(prev => ({
      ...prev,
      isActive: false
    }));
    toast.success('Journey paused');
  };

  const resumeJourney = () => {
    setJourneyStatus(prev => ({
      ...prev,
      isActive: true
    }));
    
    // Open the current location in Google Maps
    if (optimizedRoute.length > journeyStatus.currentStop) {
      const currentStop = optimizedRoute[journeyStatus.currentStop];
      openInGoogleMaps(currentStop.location.lat, currentStop.location.lng);
      toast.success('Journey resumed! Continue to your next stop.');
    }
  };

  const completeCurrentStop = () => {
    if (journeyStatus.currentStop >= optimizedRoute.length - 1) {
      setJourneyStatus(prev => ({
        ...prev,
        isActive: false,
        completedStops: [...prev.completedStops, optimizedRoute[prev.currentStop].container.id]
      }));
      toast.success('Congratulations! You have completed all stops.');
      return;
    }

    setJourneyStatus(prev => ({
      ...prev,
      currentStop: prev.currentStop + 1,
      completedStops: [...prev.completedStops, optimizedRoute[prev.currentStop].container.id]
    }));

    // Open the next location in Google Maps
    const nextStop = optimizedRoute[journeyStatus.currentStop + 1];
    openInGoogleMaps(nextStop.location.lat, nextStop.location.lng);
    toast.success('Stop completed! Navigate to the next location.');
  };

  const skipCurrentStop = () => {
    if (journeyStatus.currentStop >= optimizedRoute.length - 1) {
      toast.error('This is the last stop, cannot skip.');
      return;
    }

    setJourneyStatus(prev => ({
      ...prev,
      currentStop: prev.currentStop + 1
    }));

    // Open the next location in Google Maps
    const nextStop = optimizedRoute[journeyStatus.currentStop + 1];
    openInGoogleMaps(nextStop.location.lat, nextStop.location.lng);
    toast.success('Stop skipped. Navigate to the next location.');
  };

  return (
    <div className="bg-white shadow rounded-lg p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Saved Container Locations</h2>
          <p className="text-gray-500 mt-1">View all geolocated container positions</p>
        </div>
        <MapPin className="h-8 w-8 text-blue-600" />
      </div>

      <div className="mb-6 space-y-4">
        <div className="relative">
          <input
            type="text"
            placeholder="Search by container ID, outlet name, customer name, or phone number..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500"
          />
          <Search className="absolute left-3 top-2.5 h-5 w-5 text-gray-400" />
        </div>

        <div className="flex items-center gap-4">
          <button
            onClick={getCurrentLocation}
            disabled={isCalculatingRoute}
            className="flex items-center px-4 py-2 text-sm font-medium text-white bg-blue-600 rounded-md hover:bg-blue-700 disabled:opacity-50"
          >
            <Navigation className="h-4 w-4 mr-2" />
            {currentLocation ? 'Update Location' : 'Get Current Location'}
          </button>

          <button
            onClick={optimizeRoute}
            disabled={!currentLocation || isCalculatingRoute}
            className="flex items-center px-4 py-2 text-sm font-medium text-white bg-green-600 rounded-md hover:bg-green-700 disabled:opacity-50"
          >
            <Route className="h-4 w-4 mr-2" />
            {isCalculatingRoute ? 'Calculating...' : 'Optimize Route'}
          </button>

          {optimizedRoute.length > 0 && (
            <button
              onClick={resetRoute}
              className="flex items-center px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 rounded-md hover:bg-gray-200"
            >
              <RotateCcw className="h-4 w-4 mr-2" />
              Reset Route
            </button>
          )}
        </div>
      </div>

      {optimizedRoute.length > 0 && (
        <div className="mb-6 bg-blue-50 rounded-lg p-4">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-medium text-blue-900">Optimized Route</h3>
            {!journeyStatus.isActive ? (
              <button
                onClick={startJourney}
                className="flex items-center px-4 py-2 text-sm font-medium text-white bg-blue-600 rounded-md hover:bg-blue-700"
              >
                <Play className="h-4 w-4 mr-2" />
                Start Journey
              </button>
            ) : (
              <div className="flex items-center gap-2">
                <button
                  onClick={pauseJourney}
                  className="flex items-center px-4 py-2 text-sm font-medium text-white bg-yellow-600 rounded-md hover:bg-yellow-700"
                >
                  <Pause className="h-4 w-4 mr-2" />
                  Pause
                </button>
                <button
                  onClick={completeCurrentStop}
                  className="flex items-center px-4 py-2 text-sm font-medium text-white bg-green-600 rounded-md hover:bg-green-700"
                >
                  <Flag className="h-4 w-4 mr-2" />
                  Complete Stop
                </button>
                <button
                  onClick={skipCurrentStop}
                  className="flex items-center px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 rounded-md hover:bg-gray-200"
                >
                  <MapPinOff className="h-4 w-4 mr-2" />
                  Skip Stop
                </button>
              </div>
            )}
          </div>

          {journeyStatus.startTime && (
            <div className="mb-3 text-sm text-blue-800">
              Journey started: {format(parseISO(journeyStatus.startTime), 'PPp')}
            </div>
          )}

          <div className="space-y-3">
            {optimizedRoute.map((route, index) => (
              <div 
                key={route.container.id} 
                className={`flex items-center justify-between p-3 rounded-md shadow-sm ${
                  index === journeyStatus.currentStop && journeyStatus.isActive
                    ? 'bg-blue-100 border-2 border-blue-500'
                    : index < journeyStatus.currentStop || journeyStatus.completedStops.includes(route.container.id)
                    ? 'bg-green-50 line-through'
                    : 'bg-white'
                }`}
              >
                <div>
                  <span className="inline-block w-6 h-6 text-sm font-medium text-white bg-blue-600 rounded-full flex items-center justify-center mr-3">
                    {index + 1}
                  </span>
                  <span className="font-medium">{route.container.retail_outlet_name}</span>
                  <p className="text-sm text-gray-500 ml-9">{route.location.address}</p>
                </div>
                <div className="text-right text-sm">
                  <p className="text-gray-900">{(route.distance / 1000).toFixed(1)} km</p>
                  <p className="text-gray-500">{Math.round(route.duration / 60)} mins</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th 
                scope="col" 
                className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer"
                onClick={() => handleSort('unique_codify')}
              >
                <div className="flex items-center">
                  Container ID
                  <SortIcon field="unique_codify" />
                </div>
              </th>
              <th 
                scope="col" 
                className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer"
                onClick={() => handleSort('retail_outlet_name')}
              >
                <div className="flex items-center">
                  Outlet Name
                  <SortIcon field="retail_outlet_name" />
                </div>
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Phone Number
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Location Details
              </th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {sortedContainers.map((container) => (
              container.locations?.map((location, locationIndex) => (
                <tr 
                  key={`${container.id}-${locationIndex}`}
                  className={expandedLocation === `${container.id}-${locationIndex}` ? 'bg-blue-50' : 'hover:bg-gray-50'}
                  onClick={() => setExpandedLocation(
                    expandedLocation === `${container.id}-${locationIndex}` 
                      ? null 
                      : `${container.id}-${locationIndex}`
                  )}
                >
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                    {container.unique_codify}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {container.retail_outlet_name}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    <a 
                      href={`tel:${container.phone_number}`}
                      className="text-blue-600 hover:text-blue-800"
                      onClick={(e) => e.stopPropagation()}
                    >
                      {container.phone_number}
                    </a>
                  </td>
                  <td className="px-6 py-4 text-sm text-gray-500">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="font-medium">{location.customer_name}</p>
                        <p className="text-xs text-gray-400">
                          {format(parseISO(location.timestamp), 'PPp')}
                        </p>
                      </div>
                      <ChevronDown 
                        className={`h-5 w-5 transform transition-transform ${
                          expandedLocation === `${container.id}-${locationIndex}` ? 'rotate-180' : ''
                        }`}
                      />
                    </div>

                    {expandedLocation === `${container.id}-${locationIndex}` && (
                      <div className="mt-4 space-y-4">
                        <div>
                          <p className="text-sm font-medium text-gray-700">Address</p>
                          <p className="text-sm">{location.address}</p>
                        </div>
                        <div>
                          <p className="text-sm font-medium text-gray-700">Coordinates</p>
                          <div className="flex items-center space-x-2">
                            <p className="text-sm">
                              Lat: {location.lat.toFixed(6)}, Lng: {location.lng.toFixed(6)}
                            </p>
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                openInGoogleMaps(location.lat, location.lng);
                              }}
                              className="text-blue-600 hover:text-blue-800 text-sm"
                            >
                              View in Google Maps
                            </button>
                          </div>
                        </div>
                        {location.image && (
                          <div>
                            <p className="text-sm font-medium text-gray-700 mb-2">Location Image</p>
                            <img
                              src={location.image}
                              alt="Container location"
                              className="rounded-lg max-w-sm"
                            />
                          </div>
                        )}
                      </div>
                    )}
                  </td>
                </tr>
              ))
            ))}
          </tbody>
        </table>

        {sortedContainers.length === 0 && (
          <div className="text-center py-8 text-gray-500">
            No saved locations found
          </div>
        )}
      </div>
    </div>
  );
}