import { useState } from 'react';
import DatePicker from 'react-datepicker';
import "react-datepicker/dist/react-datepicker.css";
import { Download, FileSpreadsheet, Users, CheckCircle, FileText } from 'lucide-react';
import { format, startOfWeek, endOfWeek, isWithinInterval, parseISO, addDays, isBefore, isAfter, setHours, setMinutes, setSeconds, setMilliseconds, startOfMonth, getDate, getDay, isSameMonth } from 'date-fns';
import * as XLSX from 'xlsx';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import { ContainerData } from './Dashboard';
import toast from 'react-hot-toast';

interface ReportsProps {
  containers: ContainerData[];
}

const MAX_URL_LENGTH = 100;
const MAX_URLS_PER_CELL = 3;
const PAGE_MARGIN = 20;
const IMAGE_GAP = 10;

// Adjusted dimensions to ensure both images fit on one page
const IMAGE_WIDTH = 170;
const IMAGE_HEIGHT = 70; // Further reduced height to ensure both images fit with labels

type ExportFormat = 'excel' | 'pdf';

const STATUS_COLORS = {
  completed: '#D1FAE5'
};

const STATUS_LABELS = {
  completed: 'Completed'
};

const loadImage = (url: string): Promise<HTMLImageElement> => {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => resolve(img);
    img.onerror = reject;
    img.src = url;
  });
};

const addImageToPDF = async (
  doc: jsPDF, 
  imageUrl: string, 
  x: number, 
  y: number, 
  maxWidth: number, 
  maxHeight: number,
  label: string
): Promise<number> => {
  try {
    const img = await loadImage(imageUrl);
    const aspectRatio = img.width / img.height;
    
    let width = maxWidth;
    let height = width / aspectRatio;
    
    if (height > maxHeight) {
      height = maxHeight;
      width = height * aspectRatio;
    }
    
    const xOffset = x + (maxWidth - width) / 2;
    
    doc.addImage(img, 'JPEG', xOffset, y, width, height);

    // Add label with background
    doc.setFillColor(0, 0, 0);
    doc.setTextColor(255, 255, 255);
    doc.setFontSize(10);
    const textWidth = doc.getTextWidth(label);
    doc.roundedRect(xOffset, y + height + 2, textWidth + 6, 6, 1, 1, 'F');
    doc.text(label, xOffset + 3, y + height + 6);

    return height;
  } catch (error) {
    console.error('Error loading image:', error);
    doc.setTextColor(255, 0, 0);
    doc.text('Error loading image', x, y);
    doc.setTextColor(0, 0, 0);
    return 20;
  }
};

function truncateUrl(url: string): string {
  if (url.length <= MAX_URL_LENGTH) return url;
  const start = url.slice(0, MAX_URL_LENGTH / 2);
  const end = url.slice(-MAX_URL_LENGTH / 2);
  return `${start}...${end}`;
}

function getMonthBusinessWeeks(date: Date) {
  const monthStart = startOfMonth(date);
  const firstMonday = addDays(monthStart, (8 - getDay(monthStart)) % 7);
  const weeks = [];
  let currentMonday = firstMonday;

  while (isSameMonth(currentMonday, date)) {
    const weekEnd = addDays(currentMonday, 4); // Friday
    if (!isSameMonth(weekEnd, date)) break;

    weeks.push({
      start: setMilliseconds(setSeconds(setMinutes(setHours(currentMonday, 0), 0), 0), 0),
      end: setMilliseconds(setSeconds(setMinutes(setHours(weekEnd, 23), 59), 59), 999),
      label: `Week ${weeks.length + 1}: ${format(currentMonday, 'MMM d')} - ${format(weekEnd, 'MMM d')}`
    });

    currentMonday = addDays(currentMonday, 7);
  }

  return weeks;
}

function getBusinessWeekBounds(date: Date) {
  const weeks = getMonthBusinessWeeks(date);
  const selectedWeek = weeks.find(week => 
    isWithinInterval(date, { start: week.start, end: week.end })
  ) || weeks[0];

  return {
    weekStart: selectedWeek.start,
    weekEnd: selectedWeek.end,
    weeks
  };
}

export function Reports({ containers }: ReportsProps) {
  const [startDate, setStartDate] = useState<Date | null>(new Date());
  const [endDate, setEndDate] = useState<Date | null>(null);
  const [reportType, setReportType] = useState<'custom' | 'weekly'>('weekly');
  const [isExporting, setIsExporting] = useState(false);
  const [exportFormat, setExportFormat] = useState<ExportFormat>('pdf');

  const getFilteredContainers = () => {
    if (reportType === 'weekly' && startDate) {
      const { weekStart, weekEnd } = getBusinessWeekBounds(startDate);
      return containers.filter(container => {
        const containerDate = parseISO(container.created_at);
        return isWithinInterval(containerDate, { start: weekStart, end: weekEnd });
      });
    } else if (startDate && endDate) {
      return containers.filter(container => {
        const containerDate = parseISO(container.created_at);
        return isWithinInterval(containerDate, { 
          start: setMilliseconds(setSeconds(setMinutes(setHours(startDate, 0), 0), 0), 0),
          end: setMilliseconds(setSeconds(setMinutes(setHours(endDate, 23), 59), 59), 999)
        });
      });
    }
    return containers;
  };

  const getStats = () => {
    const filteredContainers = getFilteredContainers();
    const currentWeekStart = startOfWeek(new Date(), { weekStartsOn: 1 });
    const currentWeekEnd = endOfWeek(new Date(), { weekStartsOn: 1 });

    const allContainers = containers;
    const completedCount = allContainers.filter(c => c.status === 'completed').length;

    return {
      total: allContainers.length,
      totalCompleted: completedCount,
      completedThisWeek: allContainers.filter(c => {
        const date = parseISO(c.status_updated_at || c.created_at);
        return c.status === 'completed' && isWithinInterval(date, {
          start: currentWeekStart,
          end: currentWeekEnd
        });
      }).length,
      completedWithImages: filteredContainers.filter(c => 
        c.status === 'completed' && c.images && c.images.length > 0
      ).length,
    };
  };

  const generatePdfReport = async (filteredContainers: ContainerData[], stats: ReturnType<typeof getStats>) => {
    const doc = new jsPDF({
      orientation: 'portrait',
      unit: 'mm',
      format: 'a4'
    });

    const dateStr = reportType === 'weekly' && startDate
      ? `Week of ${format(getBusinessWeekBounds(startDate).weekStart, 'MMMM do')} - ${format(getBusinessWeekBounds(startDate).weekEnd, 'do yyyy')}`
      : startDate && endDate
        ? `${format(startDate, 'PPP')} to ${format(endDate, 'PPP')}`
        : 'All Time';

    doc.setFillColor(59, 130, 246);
    doc.rect(0, 0, doc.internal.pageSize.width, 50, 'F');
    doc.setTextColor(255, 255, 255);
    doc.setFontSize(24);
    doc.text('Container Status Report', PAGE_MARGIN, 35);

    doc.setTextColor(0, 0, 0);
    doc.setFontSize(14);
    doc.text(`Report Period: ${dateStr}`, PAGE_MARGIN, 70);

    doc.setFontSize(16);
    doc.text('Summary Statistics', PAGE_MARGIN, 90);

    const statsData = [
      ['Total Containers', stats.total],
      ['Total Completed', stats.totalCompleted],
      ['Completed This Week', stats.completedThisWeek]
    ];

    autoTable(doc, {
      head: [['Metric', 'Count']],
      body: statsData,
      startY: 100,
      theme: 'grid',
      headStyles: { fillColor: [59, 130, 246] },
      styles: { fontSize: 12 }
    });

    const completedContainers = filteredContainers.filter(c => 
      c.status === 'completed' && c.images && c.images.length > 0
    );

    if (completedContainers.length > 0) {
      for (const container of completedContainers) {
        const beforeImages = container.images.filter(img => img.type === 'before');
        const afterImages = container.images.filter(img => img.type === 'after');

        // First page with container details and before images
        doc.addPage();
        
        // Header
        doc.setFillColor(59, 130, 246);
        doc.rect(0, 0, doc.internal.pageSize.width, 40, 'F');
        doc.setTextColor(255, 255, 255);
        doc.setFontSize(20);
        doc.text('Completed Container Details', PAGE_MARGIN, 25);

        // Container details
        doc.setTextColor(0, 0, 0);
        doc.setFontSize(11); // Reduced font size for container details
        const yStart = 50;
        
        // Container information section with background
        doc.setFillColor(248, 250, 252);
        doc.rect(PAGE_MARGIN - 5, yStart - 5, doc.internal.pageSize.width - 2 * PAGE_MARGIN + 10, 40, 'F');
        
        const lineHeight = 8; // Reduced line height for more compact text
        doc.text(`Retail Outlet: ${container.retail_outlet_name}`, PAGE_MARGIN, yStart);
        doc.text(`ID: ${container.unique_codify}`, PAGE_MARGIN, yStart + lineHeight);
        doc.text(`Sales Area: ${container.sales_area}`, PAGE_MARGIN, yStart + lineHeight * 2);
        doc.text(`LGA: ${container.lga}`, PAGE_MARGIN, yStart + lineHeight * 3);
        doc.text(`Address: ${container.address}`, PAGE_MARGIN, yStart + lineHeight * 4);

        // Before Images Section
        if (beforeImages.length > 0) {
          let currentY = yStart + 50; // Adjusted starting position for images

          // Before images header with background
          doc.setFillColor(239, 246, 255);
          doc.rect(PAGE_MARGIN - 5, currentY - 5, doc.internal.pageSize.width - 2 * PAGE_MARGIN + 10, 10, 'F');
          doc.setFontSize(16);
          doc.setTextColor(59, 130, 246);
          doc.text('Before Images', PAGE_MARGIN, currentY + 3);
          currentY += 15;

          // Add up to two before images with consistent spacing
          for (let i = 0; i < Math.min(2, beforeImages.length); i++) {
            const imageHeight = await addImageToPDF(
              doc,
              beforeImages[i].url,
              PAGE_MARGIN,
              currentY,
              IMAGE_WIDTH,
              IMAGE_HEIGHT,
              'Before'
            );
            currentY += imageHeight + IMAGE_GAP + 10;
          }
        }

        // Second page with after images
        if (afterImages.length > 0) {
          doc.addPage();
          
          // Header for after images page
          doc.setFillColor(59, 130, 246);
          doc.rect(0, 0, doc.internal.pageSize.width, 40, 'F');
          doc.setTextColor(255, 255, 255);
          doc.setFontSize(20);
          doc.text(`After Images - ${container.retail_outlet_name}`, PAGE_MARGIN, 25);

          let currentY = 50;

          // After images header with background
          doc.setFillColor(240, 253, 244);
          doc.rect(PAGE_MARGIN - 5, currentY - 5, doc.internal.pageSize.width - 2 * PAGE_MARGIN + 10, 10, 'F');
          doc.setFontSize(16);
          doc.setTextColor(34, 197, 94);
          doc.text('After Images', PAGE_MARGIN, currentY + 3);
          currentY += 15;

          // Add up to two after images with consistent spacing
          for (let i = 0; i < Math.min(2, afterImages.length); i++) {
            const imageHeight = await addImageToPDF(
              doc,
              afterImages[i].url,
              PAGE_MARGIN,
              currentY,
              IMAGE_WIDTH,
              IMAGE_HEIGHT,
              'After'
            );
            currentY += imageHeight + IMAGE_GAP + 10;
          }
        }
      }
    }

    const filename = `container_report_${format(new Date(), 'yyyy-MM-dd')}.pdf`;
    doc.save(filename);
  };

  const generateExcelReport = (filteredContainers: ContainerData[], stats: ReturnType<typeof getStats>) => {
    const wb = XLSX.utils.book_new();

    const detailedData = filteredContainers
      .filter(container => container.status === 'completed')
      .map(container => {
        const imageUrls = container.images?.slice(0, MAX_URLS_PER_CELL) || [];
        const truncatedUrls = imageUrls.map((url, i) => `Image ${i + 1}: ${truncateUrl(url)}`);
        const remainingCount = (container.images?.length || 0) - MAX_URLS_PER_CELL;
        
        const imageUrlsSummary = imageUrls.length > 0
          ? truncatedUrls.join('\n') + (remainingCount > 0 ? `\n...and ${remainingCount} more` : '')
          : 'No images';

        return {
          'Unique Codify': container.unique_codify || '',
          'Sales Area': container.sales_area || '',
          'Retail Outlet Name': container.retail_outlet_name || '',
          'Address': container.address || '',
          'LGA': container.lga || '',
          'Phone Number': container.phone_number || '',
          'Status': container.status || '',
          'Created At': container.created_at ? format(parseISO(container.created_at), 'PPP') : '',
          'Images Count': container.images?.length || 0,
          'Sample Images': imageUrlsSummary
        };
      });

    const detailedWs = XLSX.utils.json_to_sheet(detailedData);
    XLSX.utils.book_append_sheet(wb, detailedWs, 'Detailed Data');

    const summaryData = [
      ['Container Status Report'],
      [''],
      ['Report Period', reportType === 'weekly' && startDate 
        ? `Week of ${format(getBusinessWeekBounds(startDate).weekStart, 'MMMM do')} - ${format(getBusinessWeekBounds(startDate).weekEnd, 'do yyyy')}`
        : `${startDate ? format(startDate, 'PPP') : 'Start'} to ${endDate ? format(endDate, 'PPP') : 'End'}`],
      [''],
      ['Status Summary'],
      ['Total Containers', stats.total],
      ['Total Completed', stats.totalCompleted],
      ['Completed This Week', stats.completedThisWeek]
    ];

    const summaryWs = XLSX.utils.aoa_to_sheet(summaryData);
    XLSX.utils.book_append_sheet(wb, summaryWs, 'Summary');

    const completedContainers = filteredContainers
      .filter(c => c.status === 'completed' && c.images && c.images.length > 0)
      .map(container => {
        const imageUrls = container.images.slice(0, MAX_URLS_PER_CELL);
        const truncatedUrls = imageUrls.map((url, i) => `Image ${i + 1}: ${truncateUrl(url)}`);
        const remainingCount = container.images.length - MAX_URLS_PER_CELL;

        return {
          'Unique Codify': container.unique_codify || '',
          'Retail Outlet Name': container.retail_outlet_name || '',
          'Sales Area': container.sales_area || '',
          'LGA': container.lga || '',
          'Number of Images': container.images.length,
          'Sample Images': truncatedUrls.join('\n') + 
            (remainingCount > 0 ? `\n...and ${remainingCount} more` : ''),
          'Completion Date': container.created_at ? format(parseISO(container.created_at), 'PPP') : '',
        };
      });

    if (completedContainers.length > 0) {
      const completedWs = XLSX.utils.json_to_sheet(completedContainers);
      XLSX.utils.book_append_sheet(wb, completedWs, 'Completed with Images');
    }

    const dateStr = reportType === 'weekly' && startDate
      ? `business_week_of_${format(getBusinessWeekBounds(startDate).weekStart, 'yyyy-MM-dd')}`
      : startDate && endDate
        ? `${format(startDate, 'yyyy-MM-dd')}_to_${format(endDate, 'yyyy-MM-dd')}`
        : 'all_time';

    XLSX.writeFile(wb, `container_report_${dateStr}.xlsx`);
  };

  const generateReport = async () => {
    try {
      setIsExporting(true);
      const filteredContainers = getFilteredContainers();
      const stats = getStats();

      if (exportFormat === 'excel') {
        generateExcelReport(filteredContainers, stats);
      } else {
        await generatePdfReport(filteredContainers, stats);
      }

      toast.success(`Report exported successfully as ${exportFormat.toUpperCase()}!`);
    } catch (error) {
      console.error('Export error:', error);
      toast.error(`Failed to export ${exportFormat.toUpperCase()} report. Please try again.`);
    } finally {
      setIsExporting(false);
    }
  };

  const stats = getStats();

  return (
    <div className="bg-white shadow rounded-lg p-6 mb-8">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Reports & Analytics</h2>
          <p className="text-gray-500 mt-1">Track and analyze completed containers</p>
        </div>
        <FileSpreadsheet className="h-8 w-8 text-blue-600" />
      </div>

      <div className="mb-8 bg-gray-50 rounded-lg p-4">
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Report Type</label>
            <div className="flex gap-4">
              <label className="inline-flex items-center">
                <input
                  type="radio"
                  className="form-radio text-blue-600"
                  value="custom"
                  checked={reportType === 'custom'}
                  onChange={(e) => setReportType(e.target.value as 'custom')}
                />
                <span className="ml-2">Custom Date Range</span>
              </label>
              <label className="inline-flex items-center">
                <input
                  type="radio"
                  className="form-radio text-blue-600"
                  value="weekly"
                  checked={reportType === 'weekly'}
                  onChange={(e) => setReportType(e.target.value as 'weekly')}
                />
                <span className="ml-2">Business Week (Mon-Fri)</span>
              </label>
            </div>
          </div>

          {reportType === 'custom' ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Start Date</label>
                <DatePicker
                  selected={startDate}
                  onChange={date => setStartDate(date)}
                  className="w-full border border-gray-300 rounded-md shadow-sm p-2"
                  placeholderText="Select start date"
                  maxDate={endDate || new Date()}
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">End Date</label>
                <DatePicker
                  selected={endDate}
                  onChange={date => setEndDate(date)}
                  className="w-full border border-gray-300 rounded-md shadow-sm p-2"
                  placeholderText="Select end date"
                  minDate={startDate}
                  maxDate={new Date()}
                />
              </div>
            </div>
          ) : (
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Select Business Week</label>
              <div className="space-y-2">
                {startDate && getBusinessWeekBounds(startDate).weeks.map((week, index) => (
                  <button
                    key={index}
                    onClick={() => setStartDate(week.start)}
                    className={`w-full text-left p-3 rounded-lg transition-colors ${
                      isWithinInterval(startDate, { start: week.start, end: week.end })
                        ? 'bg-blue-100 text-blue-800'
                        : 'bg-white hover:bg-gray-50'
                    }`}
                  >
                    {week.label}
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
        <div className="bg-blue-50 rounded-lg p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-blue-600 text-sm font-medium">Total Containers</p>
              <h3 className="text-2xl font-bold text-blue-900 mt-1">{stats.total}</h3>
            </div>
            <Users className="h-8 w-8 text-blue-600" />
          </div>
        </div>
        <div className="bg-green-50 rounded-lg p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-green-600 text-sm font-medium">Total Completed</p>
              <h3 className="text-2xl font-bold text-green-900 mt-1">{stats.totalCompleted}</h3>
            </div>
            <CheckCircle className="h-8 w-8 text-green-600" />
          </div>
        </div>
        <div className="bg-green-50 rounded-lg p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-green-600 text-sm font-medium">Completed This Week</p>
              <h3 className="text-2xl font-bold text-green-900 mt-1">{stats.completedThisWeek}</h3>
            </div>
            <CheckCircle className="h-8 w-8 text-green-600" />
          </div>
        </div>
      </div>

      <div className="flex justify-end items-center gap-4">
        <div className="flex items-center gap-2">
          <label className="inline-flex items-center">
            <input
              type="radio"
              className="form-radio text-blue-600"
              checked={exportFormat === 'excel'}
              onChange={() => setExportFormat('excel')}
            />
            <span className="ml-2 flex items-center">
              <FileSpreadsheet className="h-4 w-4 mr-1" />
              Excel
            </span>
          </label>
          <label className="inline-flex items-center">
            <input
              type="radio"
              className="form-radio text-blue-600"
              checked={exportFormat === 'pdf'}
              onChange={() => setExportFormat('pdf')}
            />
            <span className="ml-2 flex items-center">
              <FileText className="h-4 w-4 mr-1" />
              PDF
            </span>
          </label>
        </div>
        <button
          onClick={generateReport}
          disabled={isExporting || (reportType === 'custom' ? !startDate || !endDate : !startDate)}
          className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed"
        >
          <Download className="h-4 w-4 mr-2" />
          {isExporting ? 'Exporting...' : `Export ${exportFormat.toUpperCase()}`}
        </button>
      </div>
    </div>
  );
}