import { useState } from 'react';
import { Users, CheckCircle, Clock, XCircle } from 'lucide-react';
import { format, parseISO } from 'date-fns';

export interface ContainerImage {
  url: string;
  type: 'before' | 'after';
  created_at: string;
}

export interface LocationData {
  lat: number;
  lng: number;
  address: string;
  image?: string;
  timestamp: string;
  customer_name: string;
  phone_number: string;
}

export interface ContainerData {
  id: string;
  unique_codify: string;
  sales_area: string;
  retail_outlet_name: string;
  address: string;
  lga: string;
  phone_number: string;
  created_at: string;
  status: 'not_started' | 'in_progress' | 'completed';
  status_updated_at: string | null;
  images: ContainerImage[];
  locations?: LocationData[];
}

interface DashboardProps {
  containers: ContainerData[];
  setContainers: React.Dispatch<React.SetStateAction<ContainerData[]>>;
}

const STATUS_LABELS = {
  not_started: 'Not Started',
  in_progress: 'In Progress',
  completed: 'Completed'
};

export function Dashboard({ containers }: DashboardProps) {
  const [timeframe, setTimeframe] = useState<'all' | 'week' | 'month'>('all');

  // Update stats calculation to match ContainerList logic
  const stats = {
    total: containers.length,
    completed: containers.filter(c => c.status === 'completed').length,
    in_progress: containers.filter(c => 
      c.images?.some(img => img.type === 'before') && 
      !c.images?.some(img => img.type === 'after')
    ).length,
    not_started: containers.filter(c => 
      !c.images?.some(img => img.type === 'before')
    ).length
  };

  const recentContainers = [...containers]
    .sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime())
    .slice(0, 5);

  const salesAreaStats = containers.reduce((acc, container) => {
    acc[container.sales_area] = (acc[container.sales_area] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  const topSalesAreas = Object.entries(salesAreaStats)
    .sort(([, a], [, b]) => b - a)
    .slice(0, 5);

  return (
    <div className="space-y-6">
      {/* Stats Overview */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center">
            <div className="flex-shrink-0">
              <Users className="h-6 w-6 text-blue-600" />
            </div>
            <div className="ml-4">
              <h3 className="text-sm font-medium text-gray-900">Total Containers</h3>
              <p className="text-2xl font-semibold text-gray-700">{stats.total}</p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center">
            <div className="flex-shrink-0">
              <CheckCircle className="h-6 w-6 text-green-600" />
            </div>
            <div className="ml-4">
              <h3 className="text-sm font-medium text-gray-900">Completed</h3>
              <p className="text-2xl font-semibold text-gray-700">{stats.completed}</p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center">
            <div className="flex-shrink-0">
              <Clock className="h-6 w-6 text-yellow-600" />
            </div>
            <div className="ml-4">
              <h3 className="text-sm font-medium text-gray-900">In Progress</h3>
              <p className="text-2xl font-semibold text-gray-700">{stats.in_progress}</p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center">
            <div className="flex-shrink-0">
              <XCircle className="h-6 w-6 text-red-600" />
            </div>
            <div className="ml-4">
              <h3 className="text-sm font-medium text-gray-900">Not Started</h3>
              <p className="text-2xl font-semibold text-gray-700">{stats.not_started}</p>
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Recent Containers */}
        <div className="bg-white rounded-lg shadow">
          <div className="p-6">
            <h2 className="text-lg font-medium text-gray-900 mb-4">Recent Containers</h2>
            <div className="space-y-4">
              {recentContainers.map(container => (
                <div key={container.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                  <div>
                    <h3 className="text-sm font-medium text-gray-900">{container.retail_outlet_name}</h3>
                    <p className="text-sm text-gray-500">{container.unique_codify}</p>
                    <p className="text-xs text-gray-400">
                      Added {format(parseISO(container.created_at), 'MMM d, yyyy')}
                      {container.status_updated_at && container.status !== 'not_started' && (
                        <> • Status updated {format(parseISO(container.status_updated_at), 'MMM d, yyyy')}</>
                      )}
                    </p>
                  </div>
                  <div className={`
                    px-3 py-1 rounded-full text-sm font-medium
                    ${container.status === 'completed' ? 'bg-green-100 text-green-800' : ''}
                    ${container.status === 'in_progress' ? 'bg-yellow-100 text-yellow-800' : ''}
                    ${container.status === 'not_started' ? 'bg-red-100 text-red-800' : ''}
                  `}>
                    {STATUS_LABELS[container.status] || 'Unknown'}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Top Sales Areas */}
        <div className="bg-white rounded-lg shadow">
          <div className="p-6">
            <h2 className="text-lg font-medium text-gray-900 mb-4">Top Sales Areas</h2>
            <div className="space-y-4">
              {topSalesAreas.map(([area, count]) => (
                <div key={area} className="flex items-center justify-between">
                  <div className="flex-1">
                    <h3 className="text-sm font-medium text-gray-900">{area}</h3>
                    <div className="w-full bg-gray-200 rounded-full h-2 mt-2">
                      <div
                        className="bg-blue-600 h-2 rounded-full"
                        style={{ width: `${(count / stats.total) * 100}%` }}
                      />
                    </div>
                  </div>
                  <span className="ml-4 text-sm font-medium text-gray-500">{count}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}