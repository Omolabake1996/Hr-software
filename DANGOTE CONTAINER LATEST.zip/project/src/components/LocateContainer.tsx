import { useState, useRef, useCallback, useEffect } from 'react';
import { GoogleMap, useLoadScript, Marker, InfoWindow } from '@react-google-maps/api';
import { Camera, MapPin, Save, Crosshair, Loader, Layers, Move, Check, X, Filter, AlertTriangle, AlertCircle } from 'lucide-react';
import toast from 'react-hot-toast';
import { ContainerData, LocationData } from './Dashboard';

// Lagos coordinates
const LAGOS_CENTER = {
  lat: 6.5244,
  lng: 3.3792
};

const mapContainerStyle = {
  width: '100%',
  height: '100%',
};

const options = {
  mapTypeControl: true,
  streetViewControl: true,
  fullscreenControl: true,
  mapTypeId: 'roadmap' as const,
  mapTypeControlOptions: {
    style: 2, // Dropdown style
    position: 3, // Right top
  },
  zoomControl: true,
  zoomControlOptions: {
    position: 9, // Right center
  },
};

interface LocateContainerProps {
  containers: ContainerData[];
  setContainers: React.Dispatch<React.SetStateAction<ContainerData[]>>;
}

interface LocationReading {
  position: GeolocationPosition;
  timestamp: number;
  accuracy: number;
}

interface ValidationErrors {
  container: boolean;
  location: boolean;
  photo: boolean;
}

export function LocateContainer({ containers, setContainers }: LocateContainerProps) {
  const { isLoaded, loadError } = useLoadScript({
    googleMapsApiKey: import.meta.env.VITE_GOOGLE_MAPS_API_KEY || '',
    libraries: ['places'],
  });

  const [selectedLocation, setSelectedLocation] = useState<google.maps.LatLng | null>(null);
  const [currentLocation, setCurrentLocation] = useState<google.maps.LatLng | null>(null);
  const [isLocating, setIsLocating] = useState(false);
  const [selectedContainer, setSelectedContainer] = useState<string>('');
  const [locationName, setLocationName] = useState('');
  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [showConfirmation, setShowConfirmation] = useState(false);
  const [selectedMarker, setSelectedMarker] = useState<LocationData | null>(null);
  const [mapType, setMapType] = useState<google.maps.MapTypeId>('roadmap');
  const [locationError, setLocationError] = useState<string>('');
  const [isAdjusting, setIsAdjusting] = useState(false);
  const [originalLocation, setOriginalLocation] = useState<google.maps.LatLng | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [previewImage, setPreviewImage] = useState<string | null>(null);
  const mapRef = useRef<google.maps.Map>();
  const watchIdRef = useRef<number | null>(null);
  const locationReadingsRef = useRef<LocationReading[]>([]);
  const locationTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const accuracyThresholdRef = useRef<number>(15);
  const minReadingsRef = useRef<number>(8);
  const [selectedLGAs, setSelectedLGAs] = useState<string[]>([]);
  const geocoderRef = useRef<google.maps.Geocoder | null>(null);
  const [validationErrors, setValidationErrors] = useState<ValidationErrors>({
    container: false,
    location: false,
    photo: false
  });
  const [showValidationErrors, setShowValidationErrors] = useState(false);

  const uniqueLGAs = Array.from(new Set(containers.map(c => c.lga))).sort();

  const filteredContainers = selectedLGAs.length > 0
    ? containers.filter(c => selectedLGAs.includes(c.lga))
    : containers;

  const validateForm = useCallback(() => {
    const errors: ValidationErrors = {
      container: !selectedContainer,
      location: !selectedLocation || !locationName,
      photo: !previewImage
    };

    setValidationErrors(errors);
    setShowValidationErrors(true);

    return !Object.values(errors).some(error => error);
  }, [selectedContainer, selectedLocation, locationName, previewImage]);

  const handleContainerSelect = (containerId: string) => {
    setSelectedContainer(containerId);
    const selectedContainer = containers.find(c => c.id === containerId);
    if (selectedContainer) {
      setCustomerName(selectedContainer.retail_outlet_name);
      setCustomerPhone(selectedContainer.phone_number);
    } else {
      setCustomerName('');
      setCustomerPhone('');
    }
    if (showValidationErrors) {
      setValidationErrors(prev => ({ ...prev, container: !containerId }));
    }
  };

  const handleLGAChange = (lga: string) => {
    setSelectedLGAs(prev => {
      const isSelected = prev.includes(lga);
      if (isSelected) {
        return prev.filter(item => item !== lga);
      } else {
        return [...prev, lga];
      }
    });
    setSelectedContainer('');
    setCustomerName('');
    setCustomerPhone('');
  };

  const clearLGAFilters = () => {
    setSelectedLGAs([]);
    setSelectedContainer('');
    setCustomerName('');
    setCustomerPhone('');
  };

  const handleImageUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setPreviewImage(reader.result as string);
        if (showValidationErrors) {
          setValidationErrors(prev => ({ ...prev, photo: false }));
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const onMapLoad = useCallback((map: google.maps.Map) => {
    mapRef.current = map;
    geocoderRef.current = new google.maps.Geocoder();
  }, []);

  const handleMapClick = useCallback((event: google.maps.MapMouseEvent) => {
    if (isAdjusting && event.latLng) {
      setSelectedLocation(event.latLng);
      if (showValidationErrors) {
        setValidationErrors(prev => ({ ...prev, location: false }));
      }
      // Update address when manually adjusting location
      if (geocoderRef.current) {
        geocoderRef.current.geocode({ location: event.latLng }, (results, status) => {
          if (status === 'OK' && results?.[0]) {
            setLocationName(results[0].formatted_address);
          }
        });
      }
    }
  }, [isAdjusting, showValidationErrors]);

  const getCurrentLocation = useCallback(async () => {
    if (!navigator.geolocation) {
      setLocationError('Geolocation is not supported by your browser');
      return;
    }

    setIsLocating(true);
    setLocationError('');
    locationReadingsRef.current = [];

    const handleLocationUpdate = (position: GeolocationPosition) => {
      const reading = {
        position,
        timestamp: Date.now(),
        accuracy: position.coords.accuracy
      };
      locationReadingsRef.current.push(reading);

      // If we have enough readings and at least one meets accuracy threshold
      if (locationReadingsRef.current.length >= minReadingsRef.current) {
        const accurateReadings = locationReadingsRef.current.filter(r => r.position.coords.accuracy <= accuracyThresholdRef.current);
        
        if (accurateReadings.length > 0) {
          // Use the most accurate reading
          const bestReading = accurateReadings.reduce((prev, curr) => 
            curr.position.coords.accuracy < prev.position.coords.accuracy ? curr : prev
          );

          const newLocation = new google.maps.LatLng(
            bestReading.position.coords.latitude,
            bestReading.position.coords.longitude
          );

          setSelectedLocation(newLocation);
          if (showValidationErrors) {
            setValidationErrors(prev => ({ ...prev, location: false }));
          }
          setCurrentLocation(newLocation);
          setShowConfirmation(true);
          setIsLocating(false);

          if (watchIdRef.current) {
            navigator.geolocation.clearWatch(watchIdRef.current);
            watchIdRef.current = null;
          }

          if (locationTimeoutRef.current) {
            clearTimeout(locationTimeoutRef.current);
            locationTimeoutRef.current = null;
          }

          // Center map on location
          if (mapRef.current) {
            mapRef.current.panTo(newLocation);
            mapRef.current.setZoom(18);
          }

          // Get address for the location
          if (geocoderRef.current) {
            geocoderRef.current.geocode({ location: newLocation }, (results, status) => {
              if (status === 'OK' && results?.[0]) {
                setLocationName(results[0].formatted_address);
              } else {
                toast.error('Could not retrieve address for this location');
              }
            });
          }
        }
      }
    };

    const handleError = (error: GeolocationPositionError) => {
      setIsLocating(false);
      switch (error.code) {
        case error.PERMISSION_DENIED:
          setLocationError('Location permission denied');
          break;
        case error.POSITION_UNAVAILABLE:
          setLocationError('Location information unavailable');
          break;
        case error.TIMEOUT:
          setLocationError('Location request timed out');
          break;
        default:
          setLocationError('An unknown error occurred');
      }
    };

    // Start watching location
    watchIdRef.current = navigator.geolocation.watchPosition(handleLocationUpdate, handleError, {
      enableHighAccuracy: true,
      timeout: 30000,
      maximumAge: 0
    });

    // Set a timeout to stop watching if we don't get accurate enough readings
    locationTimeoutRef.current = setTimeout(() => {
      if (watchIdRef.current) {
        navigator.geolocation.clearWatch(watchIdRef.current);
        watchIdRef.current = null;
      }

      if (locationReadingsRef.current.length === 0) {
        setLocationError('Could not get location. Please try again.');
        setIsLocating(false);
      } else {
        // Use the best reading we got, even if not perfect
        const bestReading = locationReadingsRef.current.reduce((prev, curr) => 
          curr.position.coords.accuracy < prev.position.coords.accuracy ? curr : prev
        );

        const newLocation = new google.maps.LatLng(
          bestReading.position.coords.latitude,
          bestReading.position.coords.longitude
        );

        setSelectedLocation(newLocation);
        if (showValidationErrors) {
          setValidationErrors(prev => ({ ...prev, location: false }));
        }
        setCurrentLocation(newLocation);
        setShowConfirmation(true);
        setIsLocating(false);

        if (mapRef.current) {
          mapRef.current.panTo(newLocation);
          mapRef.current.setZoom(18);
        }

        // Get address for the location
        if (geocoderRef.current) {
          geocoderRef.current.geocode({ location: newLocation }, (results, status) => {
            if (status === 'OK' && results?.[0]) {
              setLocationName(results[0].formatted_address);
            } else {
              toast.error('Could not retrieve address for this location');
            }
          });
        }

        if (bestReading.position.coords.accuracy > accuracyThresholdRef.current) {
          toast.custom(
            <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4 flex items-center">
              <AlertTriangle className="h-5 w-5 text-yellow-600 mr-2" />
              <span className="text-yellow-800">
                Location accuracy is not optimal. You may want to try again or adjust the pin manually.
              </span>
            </div>
          );
        }
      }
    }, 30000);
  }, [showValidationErrors]);

  const startAdjusting = useCallback(() => {
    setIsAdjusting(true);
    setOriginalLocation(selectedLocation);
    setShowConfirmation(false);
  }, [selectedLocation]);

  const cancelAdjusting = useCallback(() => {
    setIsAdjusting(false);
    setSelectedLocation(originalLocation);
    setShowConfirmation(true);
  }, [originalLocation]);

  const confirmAdjusting = useCallback(() => {
    setIsAdjusting(false);
    setShowConfirmation(true);
    setOriginalLocation(null);
  }, []);

  const handleSaveLocation = useCallback(async () => {
    if (!validateForm()) {
      toast.error('Please fill in all required fields');
      return;
    }

    if (!selectedLocation || !selectedContainer || !locationName || !customerName || !customerPhone || !previewImage) {
      toast.error('Please fill in all required fields');
      return;
    }

    try {
      const newLocation: LocationData = {
        lat: selectedLocation.lat(),
        lng: selectedLocation.lng(),
        address: locationName,
        timestamp: new Date().toISOString(),
        customer_name: customerName,
        phone_number: customerPhone,
        image: previewImage
      };

      const updatedContainers = containers.map(container => {
        if (container.id === selectedContainer) {
          return {
            ...container,
            locations: [...(container.locations || []), newLocation]
          };
        }
        return container;
      });

      setContainers(updatedContainers);
      localStorage.setItem('containers', JSON.stringify(updatedContainers));

      // Reset form
      setSelectedLocation(null);
      setLocationName('');
      setCustomerName('');
      setCustomerPhone('');
      setSelectedContainer('');
      setShowConfirmation(false);
      setPreviewImage(null);
      setShowValidationErrors(false);
      setValidationErrors({
        container: false,
        location: false,
        photo: false
      });
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }

      toast.success('Location saved successfully');
    } catch (error) {
      console.error('Error saving location:', error);
      toast.error('Failed to save location');
    }
  }, [selectedLocation, selectedContainer, locationName, customerName, customerPhone, previewImage, containers, setContainers, validateForm]);

  useEffect(() => {
    return () => {
      if (watchIdRef.current) {
        navigator.geolocation.clearWatch(watchIdRef.current);
      }
      if (locationTimeoutRef.current) {
        clearTimeout(locationTimeoutRef.current);
      }
    };
  }, []);

  if (loadError) {
    return <div>Error loading maps</div>;
  }

  if (!isLoaded) {
    return <div>Loading maps...</div>;
  }

  return (
    <div className="space-y-6">
      <div className="bg-white shadow rounded-lg p-6">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-2xl font-bold text-gray-900">Locate Container</h2>
            <p className="text-gray-500 mt-1">Pin container locations on the map</p>
          </div>
          <MapPin className="h-8 w-8 text-blue-600" />
        </div>

        {showValidationErrors && Object.values(validationErrors).some(error => error) && (
          <div className="mb-6 bg-red-50 border border-red-200 rounded-lg p-4">
            <div className="flex items-start">
              <AlertCircle className="h-5 w-5 text-red-600 mt-0.5 mr-2" />
              <div>
                <h3 className="text-sm font-medium text-red-800">Please complete the following required fields:</h3>
                <ul className="mt-2 text-sm text-red-700 list-disc list-inside">
                  {validationErrors.container && <li>Select a container</li>}
                  {validationErrors.location && <li>Set a location (either pin on map or enter address)</li>}
                  {validationErrors.photo && <li>Upload a photo</li>}
                </ul>
              </div>
            </div>
          </div>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Form Section */}
          <div className="lg:col-span-1 space-y-4">
            {/* LGA Filter */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center">
                    <Filter className="h-4 w-4 mr-2" />
                    Filter by LGA
                  </div>
                  {selectedLGAs.length > 0 && (
                    <button
                      onClick={clearLGAFilters}
                      className="text-sm text-gray-500 hover:text-gray-700"
                    >
                      Clear filters
                    </button>
                  )}
                </div>
              </label>
              <div className="space-y-2 max-h-40 overflow-y-auto border border-gray-200 rounded-md p-2">
                {uniqueLGAs.map((lga) => (
                  <label key={lga} className="flex items-center">
                    <input
                      type="checkbox"
                      checked={selectedLGAs.includes(lga)}
                      onChange={() => handleLGAChange(lga)}
                      className="h-4 w-4 text-blue-600 rounded border-gray-300 focus:ring-blue-500"
                    />
                    <span className="ml-2 text-sm text-gray-700">{lga}</span>
                  </label>
                ))}
              </div>
              {selectedLGAs.length > 0 && (
                <p className="mt-1 text-sm text-gray-500">
                  Showing {filteredContainers.length} container(s) in {selectedLGAs.length} LGA(s)
                </p>
              )}
            </div>

            {/* Container Selection */}
            <div>
              <label className="block text-sm font-medium mb-2">
                <span className="text-gray-700">Select Container</span>
                <span className="text-red-500 ml-1">*</span>
              </label>
              <select
                value={selectedContainer}
                onChange={(e) => handleContainerSelect(e.target.value)}
                className={`w-full border rounded-md shadow-sm p-2 ${
                  validationErrors.container && showValidationErrors
                    ? 'border-red-300 focus:ring-red-500 focus:border-red-500'
                    : 'border-gray-300 focus:ring-blue-500 focus:border-blue-500'
                }`}
              >
                <option value="">Select a container...</option>
                {filteredContainers.map((container) => (
                  <option key={container.id} value={container.id}>
                    {container.unique_codify} - {container.retail_outlet_name}
                  </option>
                ))}
              </select>
              {validationErrors.container && showValidationErrors && (
                <p className="mt-1 text-sm text-red-600">Please select a container</p>
              )}
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Customer Name
              </label>
              <input
                type="text"
                value={customerName}
                onChange={(e) => setCustomerName(e.target.value)}
                className="w-full border border-gray-300 rounded-md shadow-sm p-2"
                placeholder="Enter customer name"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Customer Phone
              </label>
              <input
                type="tel"
                value={customerPhone}
                onChange={(e) => setCustomerPhone(e.target.value)}
                className="w-full border border-gray-300 rounded-md shadow-sm p-2"
                placeholder="Enter customer phone number"
              />
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">
                <span className="text-gray-700">Location Name/Address</span>
                <span className="text-red-500 ml-1">*</span>
              </label>
              <input
                type="text"
                value={locationName}
                onChange={(e) => {
                  setLocationName(e.target.value);
                  if (showValidationErrors) {
                    setValidationErrors(prev => ({ ...prev, location: !e.target.value }));
                  }
                }}
                className={`w-full border rounded-md shadow-sm p-2 ${
                  validationErrors.location && showValidationErrors
                    ? 'border-red-300 focus:ring-red-500 focus:border-red-500'
                    : 'border-gray-300 focus:ring-blue-500 focus:border-blue-500'
                }`}
                placeholder="Enter location name or address"
              />
              {validationErrors.location && showValidationErrors && (
                <p className="mt-1 text-sm text-red-600">Please set a location</p>
              )}
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">
                <span className="text-gray-700">Upload Image</span>
                <span className="text-red-500 ml-1">*</span>
              </label>
              <div className="flex items-center space-x-4">
                <label className={`flex items-center px-4 py-2 border rounded-md shadow-sm text-sm font-medium cursor-pointer ${
                  validationErrors.photo && showValidationErrors
                    ? 'border-red-300 text-red-700 bg-red-50 hover:bg-red-100'
                    : 'border-gray-300 text-gray-700 bg-white hover:bg-gray-50'
                }`}>
                  <Camera className={`h-5 w-5 mr-2 ${
                    validationErrors.photo && showValidationErrors ? 'text-red-500' : 'text-gray-500'
                  }`} />
                  Upload Photo
                  <input
                    type="file"
                    className="hidden"
                    accept="image/*"
                    onChange={handleImageUpload}
                    ref={fileInputRef}
                  />
                </label>
                {previewImage && (
                  <img
                    src={previewImage}
                    alt="Preview"
                    className="h-20 w-20 object-cover rounded-lg"
                  />
                )}
              </div>
              {validationErrors.photo && showValidationErrors && (
                <p className="mt-1 text-sm text-red-600">Please upload a photo</p>
              )}
            </div>

            <div className="pt-4 space-y-3">
              <div className="flex gap-2 mb-4">
                <button
                  onClick={() => setMapType('roadmap')}
                  className={`flex-1 px-3 py-2 text-sm font-medium rounded-md ${
                    mapType === 'roadmap'
                      ? 'bg-blue-100 text-blue-700'
                      : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                  }`}
                >
                  Road
                </button>
                <button
                  onClick={() => setMapType('satellite')}
                  className={`flex-1 px-3 py-2 text-sm font-medium rounded-md ${
                    mapType === 'satellite'
                      ? 'bg-blue-100 text-blue-700'
                      : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                  }`}
                >
                  Satellite
                </button>
                <button
                  onClick={() => setMapType('hybrid')}
                  className={`flex-1 px-3 py-2 text-sm font-medium rounded-md ${
                    mapType === 'hybrid'
                      ? 'bg-blue-100 text-blue-700'
                      : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                  }`}
                >
                  Hybrid
                </button>
              </div>

              <button
                onClick={getCurrentLocation}
                disabled={isLocating}
                className="w-full flex justify-center items-center px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {isLocating ? (
                  <Loader className="h-5 w-5 mr-2 animate-spin" />
                ) : (
                  <Crosshair className="h-5 w-5 mr-2" />
                )}
                {isLocating ? 'Getting Location...' : 'Use Current Location'}
              </button>

              {locationError && (
                <div className="bg-red-50 border border-red-200 rounded-md p-4">
                  <p className="text-sm text-red-800">{locationError}</p>
                </div>
              )}

              {showConfirmation && !locationError && !isAdjusting && (
                <div className="space-y-2">
                  <div className="bg-yellow-50 border border-yellow-200 rounded-md p-4">
                    <p className="text-sm text-yellow-800">
                      Location detected. You can adjust the pin if needed or save this position.
                    </p>
                  </div>
                  <button
                    onClick={startAdjusting}
                    className="w-full flex justify-center items-center px-4 py-2 border border-yellow-300 rounded-md shadow-sm text-sm font-medium text-yellow-700 bg-yellow-50 hover:bg-yellow-100"
                  >
                    <Move className="h-5 w-5 mr-2" />
                    Adjust Location
                  </button>
                </div>
              )}

              {isAdjusting && (
                <div className="space-y-2">
                  <div className="bg-blue-50 border border-blue-200 rounded-md p-4">
                    <p className="text-sm text-blue-800">
                      Click on the map to adjust the location pin
                    </p>
                  </div>
                  <div className="flex gap-2">
                    <button
                      onClick={cancelAdjusting}
                      className="flex-1 flex justify-center items-center px-4 py-2 border border-red-300 rounded-md shadow-sm text-sm font-medium text-red-700 bg-red-50 hover:bg-red-100"
                    >
                      <X className="h-5 w-5 mr-2" />
                      Cancel
                    </button>
                    <button
                      onClick={confirmAdjusting}
                      className="flex-1 flex justify-center items-center px-4 py-2 border border-green-300 rounded-md shadow-sm text-sm font-medium text-green-700 bg-green-50 hover:bg-green-100"
                    >
                      <Check className="h-5 w-5 mr-2" />
                      Confirm
                    </button>
                  </div>
                </div>
              )}

              <button
                onClick={handleSaveLocation}
                disabled={!selectedLocation || !selectedContainer || !locationName || !customerName || !customerPhone || !previewImage || isAdjusting}
                className="w-full flex justify-center items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                <Save className="h-5 w-5 mr-2" />
                Save Location
              </button>
            </div>
          </div>

          {/* Map Section */}
          <div className="lg:col-span-2 h-[600px] rounded-lg overflow-hidden shadow-md">
            <GoogleMap
              mapContainerStyle={mapContainerStyle}
              center={LAGOS_CENTER}
              zoom={11}
              onClick={handleMapClick}
              onLoad={onMapLoad}
              options={{
                ...options,
                mapTypeId: mapType,
              }}
            >
              {currentLocation && (
                <Marker
                  position={currentLocation}
                  icon={{
                    url: 'http://maps.google.com/mapfiles/ms/icons/blue-dot.png'
                  }}
                />
              )}
              
              {selectedLocation && !showConfirmation && (
                <Marker position={selectedLocation} />
              )}

              {containers.map(container => 
                container.locations?.map((location, index) => (
                  <Marker
                    key={`${container.id}-${index}`}
                    position={{ lat: location.lat, lng: location.lng }}
                    onClick={() => setSelectedMarker(location)}
                  />
                ))
              )}

              {selectedMarker && (
                <InfoWindow
                  position={{ lat: selectedMarker.lat, lng: selectedMarker.lng }}
                  onCloseClick={() => setSelectedMarker(null)}
                >
                  <div className="max-w-xs">
                    <p className="font-medium mb-1">
                      {containers.find(c => c.locations?.some(l => 
                        l.lat === selectedMarker.lat && l.lng === selectedMarker.lng
                      ))?.retail_outlet_name}
                    </p>
                    <p className="text-sm mb-1">{selectedMarker.address}</p>
                    <p className="text-sm mb-1">
                      <strong>Customer:</strong> {selectedMarker.customer_name}
                    </p>
                    <p className="text-sm mb-1">
                      <strong>Phone:</strong> {selectedMarker.phone_number}
                    </p>
                    <p className="text-xs text-gray-500 mb-2">
                      {new Date(selectedMarker.timestamp).toLocaleString()}
                    </p>
                    {selectedMarker.image && (
                      <img
                        src={selectedMarker.image}
                        alt="Location"
                        className="w-full rounded"
                      />
                    )}
                  </div>
                </InfoWindow>
              )}
            </GoogleMap>
          </div>
        </div>
      </div>
    </div>
  );
}