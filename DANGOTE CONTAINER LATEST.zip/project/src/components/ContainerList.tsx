import { useState } from 'react';
import { Plus, Upload, Image as ImageIcon, X, Filter, ChevronDown, Users, CheckCircle, Clock, XCircle, Camera } from 'lucide-react';
import toast from 'react-hot-toast';
import * as XLSX from 'xlsx';
import { format, parseISO } from 'date-fns';
import { storage } from '../lib/supabase';
import { ContainerData, ContainerImage } from './Dashboard';

interface ContainerListProps {
  containers: ContainerData[];
  setContainers: React.Dispatch<React.SetStateAction<ContainerData[]>>;
}

const STATUS_COLORS = {
  not_started: 'bg-red-100 text-red-800',
  in_progress: 'bg-yellow-100 text-yellow-800',
  completed: 'bg-green-100 text-green-800'
};

const STATUS_LABELS = {
  not_started: 'Not Started',
  in_progress: 'In Progress',
  completed: 'Completed'
};

export function ContainerList({ containers, setContainers }: ContainerListProps) {
  const [loading, setLoading] = useState(false);
  const [showFilters, setShowFilters] = useState(false);
  const [uploadingImage, setUploadingImage] = useState<string | null>(null);
  const [selectedImageType, setSelectedImageType] = useState<'before' | 'after'>('before');
  
  const [filters, setFilters] = useState<{
    sales_area: string[];
    lga: string[];
    status: string[];
  }>({
    sales_area: [],
    lga: [],
    status: []
  });

  // Update stats calculation to check for before images
  const stats = {
    total: containers.length,
    completed: containers.filter(c => c.status === 'completed').length,
    in_progress: containers.filter(c => 
      c.images?.some(img => img.type === 'before') && 
      !c.images?.some(img => img.type === 'after')
    ).length,
    not_started: containers.filter(c => 
      !c.images?.some(img => img.type === 'before')
    ).length
  };
  
  const [newContainer, setNewContainer] = useState({
    unique_codify: '',
    sales_area: '',
    retail_outlet_name: '',
    address: '',
    lga: '',
    phone_number: '',
    status: 'not_started' as const,
    status_updated_at: null as string | null,
    images: [] as ContainerImage[]
  });

  const uniqueSalesAreas = Array.from(new Set(containers.map(c => c.sales_area))).sort();
  const uniqueLGAs = Array.from(new Set(containers.map(c => c.lga))).sort();

  const filteredContainers = containers.filter(container => {
    const matchesSalesArea = filters.sales_area.length === 0 || filters.sales_area.includes(container.sales_area);
    const matchesLGA = filters.lga.length === 0 || filters.lga.includes(container.lga);
    const matchesStatus = filters.status.length === 0 || filters.status.includes(container.status);
    return matchesSalesArea && matchesLGA && matchesStatus;
  });

  const handleFilterChange = (field: keyof typeof filters, value: string[]) => {
    setFilters(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const clearFilters = () => {
    setFilters({
      sales_area: [],
      lga: [],
      status: []
    });
  };

  const handleStatusChange = async (containerId: string, newStatus: ContainerData['status']) => {
    try {
      const updatedContainers = containers.map(container => 
        container.id === containerId 
          ? { 
              ...container, 
              status: newStatus,
              status_updated_at: newStatus !== 'not_started' ? new Date().toISOString() : null
            }
          : container
      );
      setContainers(updatedContainers);
      localStorage.setItem('containers', JSON.stringify(updatedContainers));
      toast.success('Status updated successfully');
    } catch (error) {
      toast.error('Failed to update status');
    }
  };

  const handleImageUpload = async (containerId: string, event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const container = containers.find(c => c.id === containerId);
    if (!container) return;

    // Check if trying to upload an "after" image without having a "before" image
    const hasBeforeImage = container.images?.some(img => img.type === 'before');
    if (selectedImageType === 'after' && !hasBeforeImage) {
      toast.error('Please upload a "before" image first');
      event.target.value = '';
      return;
    }

    try {
      setUploadingImage(containerId);
      const imageUrl = await storage.uploadImage(file);
      
      const newImage: ContainerImage = {
        url: imageUrl,
        type: selectedImageType,
        created_at: new Date().toISOString()
      };

      const updatedContainers = containers.map(container => {
        if (container.id === containerId) {
          const updatedImages = [...container.images, newImage];
          const hasBeforeImage = updatedImages.some(img => img.type === 'before');
          const hasAfterImage = updatedImages.some(img => img.type === 'after');
          
          // Update status based on image types
          let newStatus = container.status;
          if (hasBeforeImage && !hasAfterImage) {
            newStatus = 'in_progress';
          } else if (hasBeforeImage && hasAfterImage) {
            newStatus = 'completed';
          }

          return { 
            ...container, 
            images: updatedImages,
            status: newStatus,
            status_updated_at: newStatus !== container.status ? new Date().toISOString() : container.status_updated_at
          };
        }
        return container;
      });
      
      setContainers(updatedContainers);
      localStorage.setItem('containers', JSON.stringify(updatedContainers));
      
      const statusMessage = selectedImageType === 'before' ? 
        'Container marked as in progress' : 
        'Container marked as completed';
      toast.success(`Image uploaded successfully. ${statusMessage}`);
    } catch (error) {
      toast.error('Failed to upload image');
    } finally {
      setUploadingImage(null);
      event.target.value = '';
    }
  };

  const handleRemoveImage = async (containerId: string, imageUrl: string) => {
    try {
      await storage.removeImage(imageUrl);

      const updatedContainers = containers.map(container => {
        if (container.id === containerId) {
          const updatedImages = container.images.filter(img => img.url !== imageUrl);
          const removedImage = container.images.find(img => img.url === imageUrl);
          
          // Determine new status based on remaining images
          const hasBeforeImage = updatedImages.some(img => img.type === 'before');
          const hasAfterImage = updatedImages.some(img => img.type === 'after');
          
          let newStatus = container.status;
          
          // If we're removing a 'before' image and there's no other 'before' image
          if (removedImage?.type === 'before' && !hasBeforeImage) {
            newStatus = 'not_started';
          }
          // If we still have a before image but no after image
          else if (hasBeforeImage && !hasAfterImage) {
            newStatus = 'in_progress';
          }
          // If we have both types of images
          else if (hasBeforeImage && hasAfterImage) {
            newStatus = 'completed';
          }

          return {
            ...container,
            images: updatedImages,
            status: newStatus,
            status_updated_at: newStatus !== container.status ? new Date().toISOString() : container.status_updated_at
          };
        }
        return container;
      });
      
      setContainers(updatedContainers);
      localStorage.setItem('containers', JSON.stringify(updatedContainers));
      toast.success('Image removed successfully');
    } catch (error) {
      toast.error('Failed to remove image');
    }
  };

  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    setLoading(true);
    try {
      const data = await file.arrayBuffer();
      const workbook = XLSX.read(data);
      const worksheet = workbook.Sheets[workbook.SheetNames[0]];
      
      const range = XLSX.utils.decode_range(worksheet['!ref'] || 'A1');
      const headers: string[] = [];
      
      for (let C = range.s.c; C <= range.e.c; ++C) {
        const cell = worksheet[XLSX.utils.encode_cell({r: range.s.r, c: C})];
        headers[C] = (cell?.v || '').toString().trim();
      }

      const expectedHeaders = [
        'UNIQUE CODIFY',
        'SALES AREA',
        'RETAIL OUTLET NAME',
        'ADDRESS',
        'LGA',
        'PHONE NUMBER'
      ];

      const headerMapping: { [key: string]: string } = {};
      const missingHeaders: string[] = [];

      expectedHeaders.forEach(expected => {
        const normalizedExpected = expected.toUpperCase().replace(/[^A-Z0-9]/g, '');
        const matchingHeader = headers.find(h => 
          h.toUpperCase().replace(/[^A-Z0-9]/g, '') === normalizedExpected
        );

        if (matchingHeader) {
          headerMapping[expected] = matchingHeader;
        } else {
          missingHeaders.push(expected);
        }
      });

      if (missingHeaders.length > 0) {
        throw new Error(
          `Missing required headers: ${missingHeaders.join(', ')}\n\n` +
          `Found headers: ${headers.join(', ')}\n\n` +
          `Please ensure your Excel file has all required columns with exact or similar names.`
        );
      }

      const jsonData = XLSX.utils.sheet_to_json(worksheet, {
        raw: false,
        defval: '',
        header: headers,
      });

      if (jsonData.length === 0) {
        throw new Error('No data found in Excel file');
      }

      const formattedData: ContainerData[] = jsonData.map((row: any) => ({
        id: crypto.randomUUID(),
        unique_codify: row[headerMapping['UNIQUE CODIFY']] || '',
        sales_area: row[headerMapping['SALES AREA']] || '',
        retail_outlet_name: row[headerMapping['RETAIL OUTLET NAME']] || '',
        address: row[headerMapping['ADDRESS']] || '',
        lga: row[headerMapping['LGA']] || '',
        phone_number: row[headerMapping['PHONE NUMBER']] || '',
        created_at: new Date().toISOString(),
        status: 'not_started' as const,
        status_updated_at: null,
        images: []
      }));

      const isValidData = formattedData.every(item => 
        item.unique_codify.trim() !== '' && 
        item.sales_area.trim() !== '' && 
        item.retail_outlet_name.trim() !== ''
      );

      if (!isValidData) {
        throw new Error('Some required fields are empty. Please ensure all records have values for UNIQUE CODIFY, SALES AREA, and RETAIL OUTLET NAME.');
      }

      setContainers(formattedData);
      localStorage.setItem('containers', JSON.stringify(formattedData));
      toast.success(`Imported ${formattedData.length} records successfully!`);
    } catch (error) {
      console.error('Excel import error:', error);
      toast.error(error instanceof Error ? error.message : 'Error importing Excel file. Please check the file format.');
    } finally {
      setLoading(false);
      event.target.value = '';
    }
  };

  async function handleAddContainer(e: React.FormEvent) {
    e.preventDefault();
    try {
      const container: ContainerData = {
        id: crypto.randomUUID(),
        ...newContainer,
        created_at: new Date().toISOString(),
        status_updated_at: null,
        images: []
      };
      
      const updatedContainers = [...containers, container];
      setContainers(updatedContainers);
      localStorage.setItem('containers', JSON.stringify(updatedContainers));
      
      setNewContainer({
        unique_codify: '',
        sales_area: '',
        retail_outlet_name: '',
        address: '',
        lga: '',
        phone_number: '',
        status: 'not_started',
        status_updated_at: null,
        images: []
      });
      
      toast.success('Container added successfully!');
    } catch (error) {
      toast.error('Error adding container');
    }
  }

  return (
    <div>
      {/* Excel Upload Section */}
      <div className="mb-8 bg-white shadow rounded-lg p-6">
        <h2 className="text-lg font-medium text-gray-900 mb-4">Import Container Data</h2>
        <div className="flex items-center space-x-4">
          <label className="flex items-center px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 cursor-pointer">
            <Upload className="h-5 w-5 mr-2 text-gray-500" />
            {loading ? 'Uploading...' : 'Upload Excel'}
            <input
              type="file"
              className="hidden"
              accept=".xlsx,.xls"
              onChange={handleFileUpload}
              disabled={loading}
            />
          </label>
          <span className="text-sm text-gray-500">Upload an Excel file with container data</span>
        </div>
      </div>

      {/* Add Container Form */}
      <div className="bg-white shadow rounded-lg p-6 mb-8">
        <h2 className="text-lg font-medium text-gray-900 mb-4">Add New Container</h2>
        <form onSubmit={handleAddContainer} className="space-y-4">
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <div>
              <label className="block text-sm font-medium text-gray-700">UNIQUE CODIFY</label>
              <input
                type="text"
                value={newContainer.unique_codify}
                onChange={(e) => setNewContainer({ ...newContainer, unique_codify: e.target.value })}
                className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-2"
                required
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700">SALES AREA</label>
              <input
                type="text"
                value={newContainer.sales_area}
                onChange={(e) => setNewContainer({ ...newContainer, sales_area: e.target.value })}
                className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-2"
                required
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700">RETAIL OUTLET NAME</label>
              <input
                type="text"
                value={newContainer.retail_outlet_name}
                onChange={(e) => setNewContainer({ ...newContainer, retail_outlet_name: e.target.value })}
                className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-2"
                required
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700">ADDRESS</label>
              <input
                type="text"
                value={newContainer.address}
                onChange={(e) => setNewContainer({ ...newContainer, address: e.target.value })}
                className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-2"
                required
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700">LGA</label>
              <input
                type="text"
                value={newContainer.lga}
                onChange={(e) => setNewContainer({ ...newContainer, lga: e.target.value })}
                className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-2"
                required
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700">PHONE NUMBER</label>
              <input
                type="text"
                value={newContainer.phone_number}
                onChange={(e) => setNewContainer({ ...newContainer, phone_number: e.target.value })}
                className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-2"
                required
              />
            </div>
          </div>
          <div className="flex justify-end">
            <button
              type="submit"
              className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700"
            >
              <Plus className="h-4 w-4 mr-2" />
              Add Container
            </button>
          </div>
        </form>
      </div>

      {/* Container List with Stats */}
      <div className="bg-white shadow rounded-lg overflow-hidden">
        <div className="p-6 border-b border-gray-200">
          {/* Statistics Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
            <div className="bg-blue-50 rounded-lg p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-blue-600 text-sm font-medium">Total Containers</p>
                  <h3 className="text-2xl font-bold text-blue-900 mt-1">{stats.total}</h3>
                </div>
                <Users className="h-8 w-8 text-blue-600" />
              </div>
            </div>
            <div className="bg-green-50 rounded-lg p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-green-600 text-sm font-medium">Completed</p>
                  <h3 className="text-2xl font-bold text-green-900 mt-1">{stats.completed}</h3>
                </div>
                <CheckCircle className="h-8 w-8 text-green-600" />
              </div>
            </div>
            <div className="bg-yellow-50 rounded-lg p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-yellow-600 text-sm font-medium">In Progress</p>
                  <h3 className="text-2xl font-bold text-yellow-900 mt-1">{stats.in_progress}</h3>
                </div>
                <Clock className="h-8 w-8 text-yellow-600" />
              </div>
            </div>
            <div className="bg-red-50 rounded-lg p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-red-600 text-sm font-medium">Not Started</p>
                  <h3 className="text-2xl font-bold text-red-900 mt-1">{stats.not_started}</h3>
                </div>
                <XCircle className="h-8 w-8 text-red-600" />
              </div>
            </div>
          </div>

          <div className="flex flex-wrap justify-between items-center gap-4">
            <h2 className="text-lg font-medium text-gray-900">Container List</h2>
            <div className="flex items-center gap-4">
              <button
                onClick={() => setShowFilters(!showFilters)}
                className="flex items-center px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-50"
              >
                <Filter className="h-4 w-4 mr-2" />
                Filters
                <ChevronDown className={`h-4 w-4 ml-2 transform transition-transform ${showFilters ? 'rotate-180' : ''}`} />
              </button>
              {(filters.sales_area.length > 0 || filters.lga.length > 0 || filters.status.length > 0) && (
                <button
                  onClick={clearFilters}
                  className="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 hover:bg-gray-200 rounded-md"
                >
                  Clear Filters
                </button>
              )}
            </div>
          </div>

          {/* Filter Panel */}
          {showFilters && (
            <div className="mt-4 grid grid-cols-1 md:grid-cols-3 gap-4">
              {/* Sales Area Filter */}
              <div>
                <h3 className="text-sm font-medium text-gray-700 mb-2">Sales Area</h3>
                <div className="space-y-2 max-h-40 overflow-y-auto">
                  {uniqueSalesAreas.map((area) => (
                    <label key={area} className="flex items-center">
                      <input
                        type="checkbox"
                        checked={filters.sales_area.includes(area)}
                        onChange={() => {
                          const newAreas = filters.sales_area.includes(area)
                            ? filters.sales_area.filter(a => a !== area)
                            : [...filters.sales_area, area];
                          handleFilterChange('sales_area', newAreas);
                        }}
                        className="h-4 w-4 text-blue-600 rounded border-gray-300"
                      />
                      <span className="ml-2 text-sm text-gray-700">{area}</span>
                    </label>
                  ))}
                </div>
              </div>

              {/* LGA Filter */}
              <div>
                <h3 className="text-sm font-medium text-gray-700 mb-2">LGA</h3>
                <div className="space-y-2 max-h-40 overflow-y-auto">
                  {uniqueLGAs.map((lga) => (
                    <label key={lga} className="flex items-center">
                      <input
                        type="checkbox"
                        checked={filters.lga.includes(lga)}
                        onChange={() => {
                          const newLGAs = filters.lga.includes(lga)
                            ? filters.lga.filter(l => l !== lga)
                            : [...filters.lga, lga];
                          handleFilterChange('lga', newLGAs);
                        }}
                        className="h-4 w-4 text-blue-600 rounded border-gray-300"
                      />
                      <span className="ml-2 text-sm text-gray-700">{lga}</span>
                    </label>
                  ))}
                </div>
              </div>

              {/* Status Filter */}
              <div>
                <h3 className="text-sm font-medium text-gray-700 mb-2">Status</h3>
                <div className="space-y-2">
                  {Object.entries(STATUS_LABELS).map(([status, label]) => (
                    <label key={status} className="flex items-center">
                      <input
                        type="checkbox"
                        checked={filters.status.includes(status)}
                        onChange={() => {
                          const newStatus = filters.status.includes(status)
                            ? filters.status.filter(s => s !== status)
                            : [...filters.status, status];
                          handleFilterChange('status', newStatus);
                        }}
                        className="h-4 w-4 text-blue-600 rounded border-gray-300"
                      />
                      <span className="ml-2 text-sm text-gray-700">{label}</span>
                    </label>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Container Cards Grid */}
        <div className="p-6">
          {loading ? (
            <div className="text-center text-gray-500">Loading...</div>
          ) : filteredContainers.length === 0 ? (
            <div className="text-center text-gray-500">
              {containers.length === 0 
                ? 'No containers found. Upload an Excel file or add containers manually.'
                : 'No containers match the current filters.'}
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredContainers.map((container) => (
                <div key={container.id} className="bg-white border rounded-lg shadow-sm overflow-hidden">
                  <div className="p-4">
                    <div className="flex justify-between items-start mb-4">
                      <div>
                        <h3 className="text-lg font-medium text-gray-900">{container.retail_outlet_name}</h3>
                        <p className="text-sm text-gray-500">{container.unique_codify}</p>
                        {container.status_updated_at && container.status !== 'not_started' && (
                          <p className="text-xs text-gray-400">
                            Status updated: {format(parseISO(container.status_updated_at), 'MMM d, yyyy')}
                          </p>
                        )}
                      </div>
                      <select
                        value={container.status}
                        onChange={(e) => handleStatusChange(container.id, e.target.value as ContainerData['status'])}
                        className={`text-sm rounded-full px-3 py-1 font-medium ${STATUS_COLORS[container.status]}`}
                      >
                        {Object.entries(STATUS_LABELS).map(([value, label]) => (
                          <option key={value} value={value}>{label}</option>
                        ))}
                      </select>
                    </div>
                    
                    <div className="space-y-2 mb-4">
                      <p className="text-sm">
                        <span className="font-medium">Sales Area:</span> {container.sales_area}
                      </p>
                      <p className="text-sm">
                        <span className="font-medium">LGA:</span> {container.lga}
                      </p>
                      <p className="text-sm">
                        <span className="font-medium">Address:</span> {container.address}
                      </p>
                      <p className="text-sm">
                        <span className="font-medium">Phone:</span> {container.phone_number}
                      </p>
                    </div>

                    <div className="border-t pt-4">
                      <div className="flex items-center justify-between mb-2">
                        <h4 className="text-sm font-medium text-gray-700">Images</h4>
                        <div className="flex items-center gap-2">
                          <select
                            value={selectedImageType}
                            onChange={(e) => setSelectedImageType(e.target.value as 'before' | 'after')}
                            className={`text-sm border border-gray-300 rounded-md px-2 py-1 ${
                              !container.images?.some(img => img.type === 'before') && selectedImageType === 'after'
                                ? 'opacity-50 cursor-not-allowed'
                                : ''
                            }`}
                            disabled={selectedImageType === 'after' && !container.images?.some(img => img.type === 'before')}
                          >
                            <option value="before">Before</option>
                            <option value="after" disabled={!container.images?.some(img => img.type === 'before')}>
                              After {!container.images?.some(img => img.type === 'before') && '(Upload before image first)'}
                            </option>
                          </select>
                          <label className="cursor-pointer">
                            <input
                              type="file"
                              accept="image/*"
                              className="hidden"
                              onChange={(e) => handleImageUpload(container.id, e)}
                              disabled={uploadingImage === container.id}
                            />
                            <div className="p-2 text-gray-500 hover:text-gray-700">
                              <Camera className="h-5 w-5" />
                            </div>
                          </label>
                        </div>
                      </div>

                      {/* Before Images */}
                      {container.images.some(img => img.type === 'before') && (
                        <div className="mb-4">
                          <h5 className="text-sm font-medium text-gray-600 mb-2">Before</h5>
                          <div className="flex flex-wrap gap-2">
                            {container.images
                              .filter(img => img.type === 'before')
                              .map((image, index) => (
                                <div key={index} className="relative group">
                                  <img
                                    src={image.url}
                                    alt={`Container ${container.unique_codify} before image ${index + 1}`}
                                    className="h-20 w-20 object-cover rounded-lg"
                                  />
                                  <button
                                    onClick={() => handleRemoveImage(container.id, image.url)}
                                    className="absolute -top-1 -right-1 hidden group-hover:flex h-6 w-6 items-center justify-center rounded-full bg-red-500 text-white"
                                  >
                                    <X className="h-4 w-4" />
                                  </button>
                                  <span className="absolute bottom-0 right-0 text-xs bg-black bg-opacity-50 text-white px-1 rounded">
                                    {format(parseISO(image.created_at), 'MMM d')}
                                  </span>
                                </div>
                              ))}
                          </div>
                        </div>
                      )}

                      {/* After Images */}
                      {container.images.some(img => img.type === 'after') && (
                        <div>
                          <h5 className="text-sm font-medium text-gray-600 mb-2">After</h5>
                          <div className="flex flex-wrap gap-2">
                            {container.images
                              .filter(img => img.type === 'after')
                              .map((image, index) => (
                                <div key={index} className="relative group">
                                  <img
                                    src={image.url}
                                    alt={`Container ${container.unique_codify} after image ${index + 1}`}
                                    className="h-20 w-20 object-cover rounded-lg"
                                  />
                                  <button
                                    onClick={() => handleRemoveImage(container.id, image.url)}
                                    className="absolute -top-1 -right-1 hidden group-hover:flex h-6 w-6 items-center justify-center rounded-full bg-red-500 text-white"
                                  >
                                    <X className="h-4 w-4" />
                                  </button>
                                  <span className="absolute bottom-0 right-0 text-xs bg-black bg-opacity-50 text-white px-1 rounded">
                                    {format(parseISO(image.created_at), 'MMM d')}
                                  </span>
                                </div>
                              ))}
                          </div>
                        </div>
                      )}

                      {container.images.length === 0 && (
                        <p className="text-sm text-gray-500 text-center">No images uploaded yet</p>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}