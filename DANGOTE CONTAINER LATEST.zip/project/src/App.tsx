import { useState, useEffect } from 'react';
import { Toaster } from 'react-hot-toast';
import { Container, Truck, LayoutDashboard, Package, FileBarChart, MapPin, List } from 'lucide-react';
import { Dashboard } from './components/Dashboard';
import { ContainerList } from './components/ContainerList';
import { Reports } from './components/Reports';
import { LocateContainer } from './components/LocateContainer';
import { SavedLocations } from './components/SavedLocations';

type View = 'dashboard' | 'containers' | 'reports' | 'locate' | 'saved-locations';

function App() {
  const [currentView, setCurrentView] = useState<View>('dashboard');
  const [containers, setContainers] = useState(() => {
    try {
      const saved = localStorage.getItem('containers');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  // Save containers to localStorage whenever they change
  useEffect(() => {
    localStorage.setItem('containers', JSON.stringify(containers));
  }, [containers]);

  const stats = {
    total: containers.length,
    completed: containers.filter(c => c.status === 'completed').length,
    in_progress: containers.filter(c => c.status === 'in_progress').length,
    not_started: containers.filter(c => c.status === 'not_started').length,
  };

  const menuItems = [
    { 
      id: 'dashboard', 
      label: 'Dashboard', 
      icon: LayoutDashboard,
      stats: stats.total,
      statsColor: 'text-blue-600'
    },
    { 
      id: 'containers', 
      label: 'Containers', 
      icon: Package,
      stats: `${stats.completed}/${stats.total}`,
      statsColor: 'text-green-600'
    },
    { 
      id: 'locate', 
      label: 'Locate Containers', 
      icon: MapPin
    },
    {
      id: 'saved-locations',
      label: 'Saved Locations',
      icon: List
    },
    { 
      id: 'reports', 
      label: 'Reports', 
      icon: FileBarChart
    },
  ] as const;

  return (
    <div className="min-h-screen bg-gray-50">
      <Toaster position="top-right" />
      
      {/* Navigation */}
      <nav className="bg-white shadow">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16">
            <div className="flex">
              <div className="flex-shrink-0 flex items-center">
                <Container className="h-8 w-8 text-blue-600" />
                <Truck className="h-8 w-8 text-blue-600 -ml-2" />
                <span className="ml-2 text-xl font-bold text-gray-900">Container Tracker</span>
              </div>
              <div className="hidden sm:ml-6 sm:flex sm:space-x-8">
                {menuItems.map(({ id, label, icon: Icon, stats, statsColor }) => (
                  <button
                    key={id}
                    onClick={() => setCurrentView(id as View)}
                    className={`
                      inline-flex items-center px-1 pt-1 text-sm font-medium
                      ${currentView === id
                        ? 'border-b-2 border-blue-500 text-gray-900'
                        : 'border-b-2 border-transparent text-gray-500 hover:border-gray-300 hover:text-gray-700'
                      }
                    `}
                  >
                    <Icon className="h-5 w-5 mr-2" />
                    <span>{label}</span>
                    {stats && (
                      <span className={`ml-2 font-semibold ${statsColor}`}>
                        {stats}
                      </span>
                    )}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Mobile menu */}
        <div className="sm:hidden">
          <div className="pt-2 pb-3 space-y-1">
            {menuItems.map(({ id, label, icon: Icon, stats, statsColor }) => (
              <button
                key={id}
                onClick={() => setCurrentView(id as View)}
                className={`
                  flex items-center w-full px-3 py-2 text-base font-medium
                  ${currentView === id
                    ? 'bg-blue-50 border-l-4 border-blue-500 text-blue-700'
                    : 'border-l-4 border-transparent text-gray-600 hover:bg-gray-50 hover:border-gray-300 hover:text-gray-800'
                  }
                `}
              >
                <Icon className="h-5 w-5 mr-2" />
                <span>{label}</span>
                {stats && (
                  <span className={`ml-2 font-semibold ${statsColor}`}>
                    {stats}
                  </span>
                )}
              </button>
            ))}
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
        {currentView === 'dashboard' && <Dashboard containers={containers} setContainers={setContainers} />}
        {currentView === 'containers' && <ContainerList containers={containers} setContainers={setContainers} />}
        {currentView === 'locate' && <LocateContainer containers={containers} setContainers={setContainers} />}
        {currentView === 'saved-locations' && <SavedLocations containers={containers} />}
        {currentView === 'reports' && <Reports containers={containers} />}
      </main>
    </div>
  );
}

export default App;