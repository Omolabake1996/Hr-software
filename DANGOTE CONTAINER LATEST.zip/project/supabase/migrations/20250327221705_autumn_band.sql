/*
  # Create containers table and security policies

  1. New Tables
    - `containers`
      - `id` (uuid, primary key)
      - `container_id` (text, unique)
      - `location` (text)
      - `branding_stage` (text)
      - `status` (text)
      - `created_at` (timestamp)
      - `user_id` (uuid, references auth.users)

  2. Security
    - Enable RLS on `containers` table
    - Add policies for authenticated users to:
      - Read all containers
      - Create containers
      - Update their own containers
*/

CREATE TABLE IF NOT EXISTS containers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  container_id text UNIQUE NOT NULL,
  location text NOT NULL,
  branding_stage text NOT NULL,
  status text NOT NULL DEFAULT 'pending',
  created_at timestamptz DEFAULT now(),
  user_id uuid REFERENCES auth.users NOT NULL DEFAULT auth.uid()
);

ALTER TABLE containers ENABLE ROW LEVEL SECURITY;

-- Allow authenticated users to read all containers
CREATE POLICY "Users can view all containers"
  ON containers
  FOR SELECT
  TO authenticated
  USING (true);

-- Allow authenticated users to insert containers
CREATE POLICY "Users can create containers"
  ON containers
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

-- Allow users to update their own containers
CREATE POLICY "Users can update own containers"
  ON containers
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);